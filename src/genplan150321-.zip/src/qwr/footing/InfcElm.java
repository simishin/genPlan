package qwr.footing;

import java.util.Map;

public interface InfcElm {
            String  writ();              //вывод в локальную базу
            void    copy(InfcElm obj);   //полное копирование принимаемого элемента
            boolean compare(InfcElm obj);//если равны, то истина (кроме статуса )
            String  print();             //печать содержимого элемента
            String  getTitle();          //2)наименование элемента
            long    getWay();           //4) состояние элемента
            boolean isAppld();           //используется
            boolean isLocal();           //создан локально
            boolean isSynxr();           //синхронизован
            String  getKey();
    default int     getWax(){return Math.toIntExact((getWay() & 31));}
    default void    setWay(long way){} //4) состояние элемента
    default int     getHasp(){return 0;}
    default void    setHasp(int hasp){}
    default int     getOrder(){return -1;}
    default void    setOrder(int order){}
    default void    setTitle(String title) { }
    default String  getDescr(){return null;}
    default void    setDescr(String descr) { }

    default String  getAlias(){return getTitle();}

    default String  getAnces(){return null;}
    default int     getAncei(){return -1;}
    default void    setAncei(int hasp) {}
    default int     getLevel(){return -1;}
    default int     getOwner(){return -1;}
    default int     getChang(){return -1;}
    default int     getRezerv(){return -1;}
}//interface InterfaceElement========================================================
