/**
 * Список писем
 */
package qwr.model.nexus;

import qwr.footing.InfcElm;
import qwr.footing.LineGuide;
import qwr.footing.LoadFile;
import qwr.footing.TreeGuide;
import qwr.model.SharSystem.GrRecords;
import qwr.model.reference.EjBuild;
import qwr.model.reference.EiChaptr;
import qwr.model.reference.EiStag;
import qwr.model.reference.EiTypDoc;
import qwr.util.BgFile;
import qwr.util.DateTim;
import qwr.util.Tranq;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import static qwr.util.BgFile.prnt;
import static qwr.util.BgFile.sepr;

public class EMail extends TreeGuide implements InfcElm, LoadFile {
    public static Map<String, InfcElm> mar =new HashMap<>(2400);//чертежи
    public static final int sizeAr=19;//количество полей в текстовом файле данных
    private static int count=1;//cчетчик для элементов по умолчанию
    // int          hasp;   //1 )ключ, время создания записи в секундах с 1 января 1970г.
    // String       title;  //2B)номер письма
    // String       descr;  //3I)содержание письма
    // long         way;    //4 ) состояние элемента  1-по умолчанию 3-из локальных
    // int          order;  //5 )порядок следования
    //----------------------
    // String   ances;      //7 )предок номер и дата письма на которое дается ответ
    // int      ancei;      //6 )предок ключ письма на которое дается ответ
    // int      level;      //8 )уровень вложенности
    //----------------------
    private int     owner;  //9 )идентификатор создателя записи
    private int     chang;  //10)время редактирования записи в секундах с 1 января 1970г.
    private int     rezerv; //11)зарезервировано
    //-----------------------
    private int     izm;    //12)вид письма, исходящее(>0)/входящее(<0)
    private int     dtv;    //13)дата письма (дней с 1970г.)
    private int     dpv;    //14)дата официального получения (дней с 1970г.)
    private String  bsdoc;  //15)тема письма
    private String  bild;   //16)адресат
    private String  razd;   //17)исполнитель письма письма(* String)
    private String  vidr;   //18)кто подписал исходящее
    private String  stag;   //19)Статус, резолюция письма
    //конструкторы-----------------------------------------------------------------
    public EMail(String title, String descr, long stas, int order) {
        super("",title, descr, stas, order);
        this.owner  = BgFile.getUserIdPrj();//идентификатор пользователя
        this.hasp    = DateTim.newSeconds();//cек1.01.1970
        this.chang   = DateTim.newSeconds();//cек1.01.1970
        bsdoc=" "; bild =""; razd=""; vidr=""; stag=""; } //EDraft------------------
    public EMail() { super("","", "", 0, 0);
        this.owner  = BgFile.getUserIdPrj();//идентификатор пользователя
        this.hasp    = DateTim.newSeconds();//cек1.01.1970
        this.chang   = DateTim.newSeconds();//cек1.01.1970
        bsdoc=" "; bild =""; razd=""; vidr=""; stag=""; } //EDraft------------------
    //специальный конструктор--------------------------------------------------------
    public EMail(String[] words) {
        super(words);
        this.owner =Integer.parseInt (words[9]); //9 )идентификатор создателя записи
        this.chang =Integer.parseInt (words[10]);//10)время редактирования в секундах с 1 января 1970г.
        this.rezerv =Integer.parseInt (words[11]);
        this.izm =Integer.parseInt (words[12]); //12)вид письма, исходящее(>0)/входящее(<0)
        this.dtv =Integer.parseInt (words[13]); //13)дата письма (дней с 1970г.)
        this.dpv =Integer.parseInt (words[14]); //14)дата официального получения (дней с 1970г.)
        this.bsdoc =(words[15]);                //15)тема письма
        this.bild =(words[16]);                 //16)адресат
        this.razd =(words[17]);                 //17)исполнитель письма письма(* String)
        this.vidr =(words[18]);                 //18)кто подписал исходящее
        this.stag =(words[19]);                 //19)Статус, резолюция письма
    }  //-----------------------------
    /**
     * полное копирование принимаемого элемента в элемент колекции кроме наименования
     * @param itm   принимаемый элемент
     * @return
     */
    @Override
    public void     copy(InfcElm itm) {
        EDraft obj = (EDraft) itm;
        super.copy(itm);
        this.owner  =obj.getOwner();//9 )идентификатор создателя записи
        this.chang  =obj.getChang();//10)время редактирования записи в секундах с 1 января 1970г.
        this.rezerv =obj.getRezerv();
        this.izm    =obj.getIzm();  //12)вид письма, исходящее(>0)/входящее(<0)
        this.dtv    =obj.getDtv();  //13)дата письма (дней с 1970г.)
        this.dpv    =obj.getDpv();  //14)дата официального получения (дней с 1970г.)
        this.bsdoc  =obj.getBsdoc();//15)тема письма
        this.bild   =obj.getBild(); //16)адресат
        this.razd   =obj.getRazd(); //17)исполнитель письма письма(* String)
        this.vidr   =obj.getVidr(); //18)кто подписал исходящее
        this.stag   =obj.getStag(); //19)Статус, резолюция письма
    }  //copy------------------------------------------------------------------------
    @Override//----------------------------------------------------------------------
    public boolean  compare(InfcElm itm) { //если равны, то истина (кроме статуса )
        EMail obj = (EMail) itm;
//        assert prnq(title+" \t"+super.compare(itm)+"\t"+izp+"/"+obj.getIzp());
        return super.compare(itm)
                && owner==obj.getOwner() //9 )идентификатор создателя записи
                && chang==obj.getChang() //10)время редактирования записи в секундах с 1 января 1970г.
                && rezerv==obj.getRezerv()
                && izm==obj.getIzm() //12)вид письма, исходящее(>0)/входящее(<0)
                && dtv==obj.getDtv() //13)дата письма (дней с 1970г.)
                && dpv==obj.getDpv() //14)дата официального получения (дней с 1970г.)
                && bsdoc.equals(obj.getBsdoc()) //15)тема письма
                && bild.equals(obj.getBild())   //16)адресат
                && razd.equals(obj.getRazd())   //17)исполнитель письма письма(* String)
                && vidr.equals(obj.getVidr())   //18)кто подписал исходящее
                && stag.equals(obj.getStag());  //19)Статус, резолюция письма
    }//compare-----------------------------------------------------------------------

    @Override//----------------------------------------------------------------------
    public String   writ(){ return super.writ()
            + owner +sepr + chang +sepr + rezerv +sepr
            + izm +sepr + dtv +sepr + dpv +sepr + (bsdoc.isEmpty()?" ":bsdoc ) +sepr
            + (bild.isEmpty()?" ": bild) +sepr + (razd.isEmpty()?" ":razd ) +sepr
            + (vidr.isEmpty()?" ":vidr ) +sepr + (stag.isEmpty()?" ":stag ) +sepr;}
    //-----------------------------------------------------------------------------
    /**
     * Приведение к стандарту встречающихся записи в исходных документах
     *     Проверяю на наличие в базе.если элемент найден, то делаю подстановку
     * @param nmail номер письма
     * @param dmail дата письма  (DateTim.convertStringR)
     * @param author автор письма (EjAuthor.normalize)
     * @return ключ письма
     */
    public static String normalize(String nmail, int dmail, String author){
        if (nmail==null) return " ";//строка слишком мала - не проверяю
        if (nmail.isBlank()) return " ";//строка слишком мала - не проверяю

//        StringBuilder s=new StringBuilder(str.toUpperCase(Locale.ROOT));
        StringBuilder s=new StringBuilder(str.toUpperCase(Locale.ROOT)
                .replace(',',' ').replace(';',' '));
        StringBuilder rez=new StringBuilder(s.length()+1);
        int i,j,n;
        String sa, sb;
//        prnt("k\ti\tj\tn\t (i<j)\t (j<n)\t"+s.length());
        for (int k=0; k<s.length(); k=i+1) {
            i=s.indexOf(" ",k);
            j=s.indexOf("И",k);
            n=s.indexOf(" ",i+1);
//            prnt("\n"+k+"\t"+i+"\t"+j+" \t"+n+"\t"+(i<j)+" \t"+(j<n)+" \t=");
            if (i<j || j==-1){
//                prnt("@");
                sa= s.substring(k,i);
                if (j<n && j>0 && (j-i)<4) sb= s.substring(j,n);
                else sb="";
            }
            else  {
//                prnt("#");
                sa= s.substring(k,j);
                sb= s.substring(j,i);
            }
            if (k==j || k==i )continue;
//            prnt(sa+"~~"+sb+"$");
            rez.append(sa).append(sb).append(" ");
//            if (mar.putIfAbsent(sa, new EDraft(sa," ",17,-1))==null)
//                GrRecords.MAILJ.shift();//ставлю флаг наличия модификации списка
        }//for
        return String.valueOf(rez);
    }//normalize---------------------------------------------------------------------
    /**
     * вызывается из LDocPrj > readFileXslx
     * @param srt разобранная строка нового элемента
     * @param cRD массив сответствия разобранной строки полям нового элемента
     * @param sheetName имя листа таблицы источника нового элемента
     */
//    @Override
    public void     parse(String[] srt, int[] cRD, String sheetName) {
        EMail obj = new EMail();
        for (int i=0; i<cRD.length; i++) {//перебор вариантов полей
            switch (cRD[i]){
                case 0:                break;
                case 1:
                case 2:
                case 5:
                case 6:
                case 7:
                case 8:
                case 3:
                case 4:
                case 9:
                default:prnt("EMail > parse ~"+cRD[i]+">"+srt[i]+" ");continue;//что то пошло не так
            }//switch
        }//for lRctc
        obj.setOrder(count++);
        obj.setWay(3);
        obj.setHasp(LineGuide.questHasp(mar,obj.hashCode()));
//        if (LineGuide.integrate(mar,obj,0)>0) GrRecords.DRAFT.shift();
        return;//добавил в список
    }    //parse---------------------------------------------------------------------
    @Override
    public String   getKey() { return title; } //--------------------------------------
    public String   getBsdoc() { return bsdoc; }
    public void     setBsdoc(String bsdoc) { this.bsdoc = bsdoc; }
    public String   getBild() { return bild; }
    public void     setBild(String bild) { this.bild = bild; }
    public String   getRazd() { return razd; }
    public void     setRazd(String razd) { this.razd = razd; }
    public String   getVidr() { return vidr; }
    public void     setVidr(String vidr) { this.vidr = vidr; }
    public String   getStag() { return stag; }
    public void     setStag(String stag) { this.stag = stag; }
    public int      getIzm() { return izm; }//11C) приведенный номер изменения (* int)
    public void     setIzm(int izm) { this.izm = izm; }//11C) приведенный номер изменения (* int)
    public int      getDtv() { return dtv; } //12D) дата официального получения (дней с 1970г.)
    public void     setDtv(int dtv) { this.dtv = dtv; } //12D) дата официального получения (дней с 1970г.)
    public int      getDpv() { return dpv; }
    public void     setDpv(int dpv) { this.dpv = dpv; }
    public int      getOwner() { return owner; }
    public void     setOwner(int owner) { this.owner = owner; }
    public int      getChang() { return chang; }
    public void     setChang(int chang) { this.chang = chang; }
    public int      getRezerv() { return rezerv; }
    public void     setRezerv(int rezerv) { this.rezerv = rezerv; }
    @Override
    public String   print(){  return
            bsdoc+"\t"+ bild +"   \t"+razd+"\t"+vidr+"\t."+ stag +".\t"+izm+"\t"+dtv+"\t"+
                    super.print();
    } //print------------------------------------------------------------------------

} //class EMail
