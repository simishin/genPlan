package qwr.reports;

public interface Decor {
}
