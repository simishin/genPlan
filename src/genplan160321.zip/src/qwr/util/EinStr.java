/**
 * Элемент для сохранения данных при распознавания строки DateTim > convertStringR
 */
package qwr.util;

public class EinStr {
    public  int     i;
    public String   s;
}//class EinStr
