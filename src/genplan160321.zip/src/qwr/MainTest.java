package qwr;

import qwr.util.Tranq;

import java.util.Locale;

import static qwr.util.BgFile.prnq;
import static qwr.util.BgFile.prnt;

public class MainTest {
//    public static Map<String, InfcElm> lnTest=new HashMap<>(80);//виды фирм


    public static void main(String[] args) {
        prnq("\n------- Testing ----------");
        String si;
        String[] ars = {" 16-01962\n  16-01363и3 и5    \n" +
                "15-00720    И2\n" + "15-08721  19-09720    И2",
        "16-01962\n" + "16-01963   16-01363и3     \n" +
                "15-00720    И2\n" +  "15-08721  19-09720",
                "  ","26-21363и3","36-91363"};
        String[] arg ={  "Ждаморева\n" +
                "О.П. № 1926 \n" +
                "от 14.06.2019 \n" +
                "и № 2116 от 03.07.2019\n",
               ""
        };

        for (int i=0; i<ars.length; i++) {
            si = Tranq.purifyin(ars[i]);
            prnq(i+">\t" + si + "<\n\t"+ normal(si));
        }
    }//main


    /**
     * нормализация списка номеров проектов с разделением на номер и изменение
     * @param str исходная строка списка проектов
     * @return
     */
    public static String normal(String str){
        assert str!=null: "! EDraft > normalize: str = null !";
        if(str.isBlank()) return " ";
        //приведение разделителей
        StringBuilder s=new StringBuilder(str.toUpperCase(Locale.ROOT)
                .replace(',',' ').replace(';',' '));
        StringBuilder rez=new StringBuilder(s.length()+1);
        int i,j,n;
        String sa, sb;
        prnt("k\ti\tj\tn\t (i<j)\t (j<n)\t"+s.length());
        for (int k=0; k<s.length(); k=i+1) {
            i=s.indexOf(" ",k);
            j=s.indexOf("И",k);
            n=s.indexOf(" ",i+1);
            prnt("\n"+k+"\t"+i+"\t"+j+" \t"+n+"\t"+(i<j)+" \t"+(j<n)+" \t=");
            if (i<j || j==-1){
                prnt("@");
                sa= s.substring(k,i);
                if (j<n && j>0 && (j-i)<4) sb= s.substring(j,n);
                else sb="";
            }
            else  {
                prnt("#");
                sa= s.substring(k,j);
                sb= s.substring(j,i);
            }
            if (k==j || k==i )continue;
            prnt(sa+"~~"+sb+"$");
            rez.append(sa).append(sb).append(" ");
        }
        prnq("\n");
        return String.valueOf(rez);
    }
}// class MainTest
